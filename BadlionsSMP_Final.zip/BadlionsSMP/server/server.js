require("dotenv").config();
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "yourpassword",
    database: "badlions_smp"
});

db.connect(err => {
    if (err) throw err;
    console.log("Connected to MySQL Database!");
});

// Register User
app.post("/register", async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    db.query("INSERT INTO users (username, password) VALUES (?, ?)", 
        [username, hashedPassword], 
        (err, result) => {
            if (err) return res.status(500).json({ error: err });
            res.json({ message: "User registered!" });
        }
    );
});

// Login User
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    db.query("SELECT * FROM users WHERE username = ?", [username], async (err, result) => {
        if (err) return res.status(500).json({ error: err });
        if (result.length === 0) return res.status(401).json({ message: "User not found" });

        const validPassword = await bcrypt.compare(password, result[0].password);
        if (!validPassword) return res.status(401).json({ message: "Invalid password" });

        const token = jwt.sign({ id: result[0].id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ token, username: result[0].username });
    });
});

app.listen(3000, () => {
    console.log("API running on http://localhost:3000");
});
