import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  app.get("/api/rankings", (_req, res) => {
    const rankings = [
      { username: "Player1", kills: 150, deaths: 45, kdr: 3.33 },
      { username: "Player2", kills: 120, deaths: 50, kdr: 2.40 },
      { username: "Player3", kills: 100, deaths: 40, kdr: 2.50 },
    ];
    res.json(rankings);
  });

  app.get("/api/store", (_req, res) => {
    const items = [
      { id: 1, name: "VIP Rank", price: 1000, description: "Get VIP privileges" },
      { id: 2, name: "MVP Rank", price: 2000, description: "Get MVP privileges" },
      { id: 3, name: "Elite Rank", price: 3000, description: "Get Elite privileges" },
    ];
    res.json(items);
  });

  app.get("/api/events", (_req, res) => {
    const events = [
      { id: 1, name: "PvP Tournament", date: "2024-04-01", description: "Battle it out!" },
      { id: 2, name: "Build Contest", date: "2024-04-15", description: "Show your creativity" },
      { id: 3, name: "Survival Games", date: "2024-04-30", description: "Last player standing" },
    ];
    res.json(events);
  });

  const httpServer = createServer(app);
  return httpServer;
}
