import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

export default function ServerStatus() {
  const { data: status } = useQuery({
    queryKey: ["/api/status"],
    queryFn: () => ({ online: true, players: 42 }),
  });

  if (!status) return null;

  return (
    <Badge
      variant={status.online ? "default" : "destructive"}
      className="mr-4"
    >
      {status.online ? `${status.players} Online` : "Offline"}
    </Badge>
  );
}
