import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function Navbar() {
  const [location] = useLocation();
  const [username, setUsername] = useState("");
  const { toast } = useToast();

  const isActive = (path: string) => {
    return location === path;
  };

  const handleLogin = () => {
    if (username.trim()) {
      toast({
        title: "Welcome!",
        description: `Logged in as ${username}`,
      });
    }
  };

  return (
    <nav className="bg-primary/95 backdrop-blur supports-[backdrop-filter]:bg-primary/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex space-x-8">
              <Link href="/">
                <span className={`text-primary-foreground hover:text-primary-foreground/80 px-3 py-2 font-semibold border-b-2 cursor-pointer ${
                  isActive('/') ? 'border-primary-foreground' : 'border-transparent'
                }`}>
                  Home
                </span>
              </Link>
              <Link href="/events">
                <span className={`text-primary-foreground hover:text-primary-foreground/80 px-3 py-2 font-semibold border-b-2 cursor-pointer ${
                  isActive('/events') ? 'border-primary-foreground' : 'border-transparent'
                }`}>
                  Event
                </span>
              </Link>
              <Link href="/store">
                <span className={`text-primary-foreground hover:text-primary-foreground/80 px-3 py-2 font-semibold border-b-2 cursor-pointer ${
                  isActive('/store') ? 'border-primary-foreground' : 'border-transparent'
                }`}>
                  Rank
                </span>
              </Link>
            </div>
          </div>
          <div className="flex items-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="secondary">Login</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Login with Minecraft Username</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <Input 
                    placeholder="Enter your Minecraft username" 
                    value={username} 
                    onChange={(e) => setUsername(e.target.value)}
                  />
                  <Button onClick={handleLogin}>Login</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>
    </nav>
  );
}