import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface StoreItemProps {
  name: string;
  price: number;
  description: string;
}

export default function StoreItem({ name, price, description }: StoreItemProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>{name}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
      <CardFooter>
        <div className="flex justify-between items-center w-full">
          <span className="text-lg font-bold">{price} coins</span>
          <Button>Purchase</Button>
        </div>
      </CardFooter>
    </Card>
  );
}
