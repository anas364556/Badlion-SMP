import { useState } from "react";

function App() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    async function login() {
        let res = await fetch("http://localhost:3000/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });
        let data = await res.json();
        if (data.token) {
            localStorage.setItem("token", data.token);
            alert("Logged in as " + data.username);
        } else {
            alert(data.message);
        }
    }

    return (
        <div>
            <h1>Badlions SMP Login</h1>
            <input type="text" placeholder="Username" onChange={e => setUsername(e.target.value)} />
            <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} />
            <button onClick={login}>Login</button>
        </div>
    );
}

export default App;
