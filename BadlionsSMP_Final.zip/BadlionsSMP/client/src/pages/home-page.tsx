import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SiDiscord } from "react-icons/si";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <div 
        className="h-[500px] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://cdn.wallpapersafari.com/51/51/PFOyhT.jpg")'
        }}
      >
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-center text-white max-w-3xl mx-auto">
            <h1 className="text-5xl font-bold mb-4">Welcome to Badlions SMP</h1>
            <p className="text-xl mb-6">The ultimate survival multiplayer experience</p>
            <div className="flex justify-center mt-8">
              <Button 
                variant="secondary" 
                size="lg"
                onClick={() => window.open('https://discord.gg/d8jTDCPyz6', '_blank')}
                className="flex items-center gap-2 px-8 py-6 text-lg"
              >
                <SiDiscord className="w-6 h-6" />
                Join our Discord
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-2">Survival</h3>
              <p>Experience pure survival gameplay with friends and foes</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-2">Community</h3>
              <p>Join a thriving community of players from around the world</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-2">Events</h3>
              <p>Participate in regular events and win awesome rewards</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}