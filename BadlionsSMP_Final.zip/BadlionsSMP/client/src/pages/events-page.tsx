import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function EventsPage() {
  const { toast } = useToast();
  const { data: events } = useQuery({
    queryKey: ["/api/events"],
  });

  const handleRegister = (eventId: number, eventName: string) => {
    // TODO: Implement actual registration logic
    toast({
      title: "Registered Successfully",
      description: `You have registered for the ${eventName}`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8">Upcoming Events</h1>
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>PvP Tournament</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-2">
                Battle it out in our PvP arena! Show your combat skills and win amazing prizes.
              </p>
              <p className="font-semibold mb-2">Date: April 1, 2024</p>
              <p className="text-sm text-muted-foreground">
                Prizes:
                <ul className="list-disc ml-4 mt-1">
                  <li>1st Place: 5000 coins</li>
                  <li>2nd Place: 3000 coins</li>
                  <li>3rd Place: 1000 coins</li>
                </ul>
              </p>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full"
                onClick={() => handleRegister(1, "PvP Tournament")}
              >
                Register for PvP Tournament
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Block Building Contest</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-2">
                Showcase your creativity in our building competition! Build the most impressive structure.
              </p>
              <p className="font-semibold mb-2">Date: April 15, 2024</p>
              <p className="text-sm text-muted-foreground">
                Prizes:
                <ul className="list-disc ml-4 mt-1">
                  <li>1st Place: 5000 coins + MVP rank</li>
                  <li>2nd Place: 3000 coins + VIP rank</li>
                  <li>3rd Place: 1000 coins</li>
                </ul>
              </p>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full"
                onClick={() => handleRegister(2, "Block Building Contest")}
              >
                Register for Building Contest
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}