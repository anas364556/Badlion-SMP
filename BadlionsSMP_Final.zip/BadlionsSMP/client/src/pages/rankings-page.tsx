import { useQuery } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function RankingsPage() {
  const { data: rankings } = useQuery({
    queryKey: ["/api/rankings"],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8">Player Rankings</h1>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Rank</TableHead>
              <TableHead>Player</TableHead>
              <TableHead>Kills</TableHead>
              <TableHead>Deaths</TableHead>
              <TableHead>K/D Ratio</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rankings?.map((player: any, index: number) => (
              <TableRow key={player.username}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>{player.username}</TableCell>
                <TableCell>{player.kills}</TableCell>
                <TableCell>{player.deaths}</TableCell>
                <TableCell>{player.kdr.toFixed(2)}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
