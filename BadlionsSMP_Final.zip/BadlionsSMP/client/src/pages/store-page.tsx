import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function StorePage() {
  const { toast } = useToast();
  const { data: items } = useQuery({
    queryKey: ["/api/store"],
  });

  const handlePurchase = (rankName: string, price: number) => {
    // TODO: Implement actual purchase logic
    toast({
      title: "Purchase pending",
      description: `Attempting to purchase ${rankName} rank for ${price} coins`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold mb-8">Server Ranks</h1>
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>VIP Rank</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xl font-bold mb-4">1000 coins</p>
              <div className="space-y-2">
                <h3 className="font-semibold">Benefits:</h3>
                <ul className="list-disc ml-4 space-y-1">
                  <li>Colored name in chat</li>
                  <li>Access to /fly command</li>
                  <li>Special VIP kit daily</li>
                  <li>Priority server access</li>
                  <li>5 home locations</li>
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full"
                onClick={() => handlePurchase("VIP", 1000)}
              >
                Purchase VIP Rank
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>MVP Rank</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xl font-bold mb-4">2000 coins</p>
              <div className="space-y-2">
                <h3 className="font-semibold">Benefits:</h3>
                <ul className="list-disc ml-4 space-y-1">
                  <li>All VIP benefits</li>
                  <li>Rainbow colored name</li>
                  <li>Access to /heal command</li>
                  <li>Premium MVP kit daily</li>
                  <li>10 home locations</li>
                  <li>Custom join messages</li>
                  <li>Particle effects</li>
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full"
                onClick={() => handlePurchase("MVP", 2000)}
              >
                Purchase MVP Rank
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}