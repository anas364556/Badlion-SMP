package com.badlions.smp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BadlionsPlugin extends JavaPlugin {
    private Connection connection;

    @Override
    public void onEnable() {
        getLogger().info("Badlions SMP Plugin Enabled!");
        connectDatabase();
    }

    private void connectDatabase() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/badlions_smp", "root", "yourpassword");
            getLogger().info("Connected to MySQL Database!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateCoins(Player player, int amount) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE players SET coins = ? WHERE uuid = ?");
            stmt.setInt(1, amount);
            stmt.setString(2, player.getUniqueId().toString());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void checkRank(Player player) {
        try {
            PreparedStatement stmt = connection.prepareStatement("SELECT rank FROM players WHERE uuid = ?");
            stmt.setString(1, player.getUniqueId().toString());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String rank = rs.getString("rank");
                player.sendMessage(ChatColor.GOLD + "Your Rank: " + rank);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
